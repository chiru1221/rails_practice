class User < ApplicationRecord
  has_secure_password
  has_many :reviews
  validates :role, inclusion: {in: ['admin', 'reviewer']}

  def admin?
    role == 'admin'
  end

  def reviewer?
    role == 'reviewer'
  end
end
