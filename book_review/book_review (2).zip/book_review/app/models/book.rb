class Book < ApplicationRecord
  has_many :reviews
end
